Signal ICT Package

A Python package for signal processing with unitary and trigonometric signals.

## Installation

```bash
pip install signal-ICT-Rudra-92400133129

Usage
pythonfrom signal_ICT_Rudra_92400133129 import unitary_signals, trigonometric_signals, operations


Features

Unitary signal processing
Trigonometric signal operations
Signal manipulation operations